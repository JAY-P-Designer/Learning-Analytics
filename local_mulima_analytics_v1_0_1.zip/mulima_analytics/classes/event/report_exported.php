<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Learning Analytics report exported.
 *
 * @package    local_mulima_analytics
 * @copyright  2026 Joaquim Pascoal Mulima Junior
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_mulima_analytics\event;

defined('MOODLE_INTERNAL') || die();

/** Records access to report exports containing institutional or personal data. */
final class report_exported extends \core\event\base {
    protected function init(): void {
        $this->data['crud'] = 'r';
        $this->data['edulevel'] = self::LEVEL_OTHER;
    }

    public static function get_name(): string {
        return get_string('eventreportexported', 'local_mulima_analytics');
    }

    public function get_description(): string {
        return "The user with id '{$this->userid}' exported the '{$this->other['report']}' Learning Analytics report.";
    }

    public function get_url(): \moodle_url {
        return new \moodle_url('/local/mulima_analytics/' . $this->other['source']);
    }

    protected function validate_data(): void {
        parent::validate_data();
        if (empty($this->other['report']) || empty($this->other['source'])) {
            throw new \coding_exception('The report and source values are required.');
        }
    }
}
